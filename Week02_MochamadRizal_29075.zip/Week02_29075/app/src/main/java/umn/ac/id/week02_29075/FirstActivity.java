package umn.ac.id.week02_29075;

import android.app.Activity;

public class FirstActivity extends Activity {
}
